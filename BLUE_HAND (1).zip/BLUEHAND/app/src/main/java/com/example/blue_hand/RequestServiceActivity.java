package com.example.bluehand;

import android.content.Intent;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RequestServiceActivity extends AppCompatActivity {

    EditText name, phone, address;
    Spinner service;
    Button findBtn, viewBtn, saveBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_service);

        // 🔹 Link UI
        name = findViewById(R.id.name);
        phone = findViewById(R.id.phone);
        address = findViewById(R.id.address);
        service = findViewById(R.id.service);
        findBtn = findViewById(R.id.findBtn);
        viewBtn = findViewById(R.id.viewBtn);
        saveBtn = findViewById(R.id.saveBtn);

        // 🔹 SharedPreferences (ONLY for saving, not loading)
        SharedPreferences sp = getSharedPreferences("BlueHandPrefs", MODE_PRIVATE);

        // 🔹 Spinner data
        String services[] = {
                "Select Service",
                "Electrician",
                "Plumber",
                "Cook",
                "Shifting Help",
                "Gas Repair",
                "Cleaning",
                "Other"
        };

        ArrayAdapter adapter = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                services
        );

        service.setAdapter(adapter);

        // 🔹 SAVE BUTTON (only saves data)
        saveBtn.setOnClickListener(v -> {

            String userName = name.getText().toString().trim();
            String userPhone = phone.getText().toString().trim();
            String userAddress = address.getText().toString().trim();
            String userService = service.getSelectedItem().toString();

            // ✅ Validation
            if(userName.isEmpty())
            {
                name.setError("Enter Name");
                return;
            }

            if(userPhone.isEmpty() || userPhone.length() != 10)
            {
                phone.setError("Enter valid phone");
                return;
            }

            if(userAddress.isEmpty())
            {
                address.setError("Enter Address");
                return;
            }

            if(userService.equals("Select Service"))
            {
                Toast.makeText(this, "Select service", Toast.LENGTH_SHORT).show();
                return;
            }

            // ✅ Save to SharedPreferences
            SharedPreferences.Editor editor = sp.edit();
            editor.putString("name", userName);
            editor.putString("phone", userPhone);
            editor.putString("address", userAddress);
            editor.apply();

            // ✅ Save to Database
            DBHelper dbHelper = new DBHelper(this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues cv = new ContentValues();
            cv.put("name", userName);
            cv.put("phone", userPhone);
            cv.put("address", userAddress);
            cv.put("service", userService);

            db.insert("requests", null, cv);
            db.close();

            Toast.makeText(this, "Data Saved Successfully", Toast.LENGTH_SHORT).show();

            // 🔹 Clear fields
            name.setText("");
            phone.setText("");
            address.setText("");
            service.setSelection(0);
        });

        // 🔹 FIND BUTTON (save + open map)
        findBtn.setOnClickListener(v -> {

            String userName = name.getText().toString().trim();
            String userPhone = phone.getText().toString().trim();
            String userAddress = address.getText().toString().trim();
            String userService = service.getSelectedItem().toString();

            // ✅ Validation
            if(userName.isEmpty())
            {
                name.setError("Enter Name");
                return;
            }

            if(userPhone.isEmpty() || userPhone.length() != 10)
            {
                phone.setError("Enter valid phone");
                return;
            }

            if(userAddress.isEmpty())
            {
                address.setError("Enter Address");
                return;
            }

            if(userService.equals("Select Service"))
            {
                Toast.makeText(this, "Select service", Toast.LENGTH_SHORT).show();
                return;
            }

            // ✅ Save to SharedPreferences
            SharedPreferences.Editor editor = sp.edit();
            editor.putString("name", userName);
            editor.putString("phone", userPhone);
            editor.putString("address", userAddress);
            editor.apply();

            // ✅ Save to Database
            DBHelper dbHelper = new DBHelper(this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues cv = new ContentValues();
            cv.put("name", userName);
            cv.put("phone", userPhone);
            cv.put("address", userAddress);
            cv.put("service", userService);

            db.insert("requests", null, cv);
            db.close();

            // ✅ Open MapActivity
            Intent intent = new Intent(
                    RequestServiceActivity.this,
                    MapActivity.class
            );

            intent.putExtra("name", userName);
            intent.putExtra("phone", userPhone);
            intent.putExtra("address", userAddress);
            intent.putExtra("service", userService);

            startActivity(intent);

            // 🔹 Clear fields
            name.setText("");
            phone.setText("");
            address.setText("");
            service.setSelection(0);
        });

        // 🔹 VIEW BUTTON (open new screen)
        viewBtn.setOnClickListener(v -> {
            Intent intent = new Intent(
                    RequestServiceActivity.this,
                    ViewRequestsActivity.class
            );
            startActivity(intent);
        });
    }
}