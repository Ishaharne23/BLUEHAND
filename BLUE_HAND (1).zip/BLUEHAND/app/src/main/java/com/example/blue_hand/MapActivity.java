package com.example.bluehand;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.osmdroid.api.IMapController;
import org.osmdroid.config.Configuration;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MapActivity extends AppCompatActivity {

    MapView map;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);

        Configuration.getInstance().setUserAgentValue(getPackageName());

        setContentView(R.layout.activity_map);

        map=findViewById(R.id.map);

        map.setMultiTouchControls(true);

        String address=getIntent().getStringExtra("address");

        String service=getIntent().getStringExtra("service");

        Geocoder geocoder=
                new Geocoder(this, Locale.getDefault());

        try {

            List<Address> list=
                    geocoder.getFromLocationName(address,1);

            if(list!=null && !list.isEmpty())
            {

                double lat=
                        list.get(0).getLatitude();

                double lon=
                        list.get(0).getLongitude();

                GeoPoint userLocation=
                        new GeoPoint(lat,lon);

                IMapController controller=
                        map.getController();

                controller.setZoom(16.0);

                controller.setCenter(userLocation);

                Marker marker=
                        new Marker(map);

                marker.setPosition(userLocation);

                marker.setTitle(service+" Service Location");

                map.getOverlays().add(marker);

            }
            else
            {
                Toast.makeText(this,
                        "Address not found",
                        Toast.LENGTH_SHORT).show();
            }

        }
        catch(IOException e)
        {
            e.printStackTrace();
        }

    }
}