package com.example.bluehand;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ViewRequestsActivity extends AppCompatActivity {

    TextView dataTxt;
    Button backBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_requests);

        dataTxt = findViewById(R.id.dataTxt);
        backBtn = findViewById(R.id.backBtn);

        // 🔹 Load data from DB
        DBHelper dbHelper = new DBHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM requests", null);

        if(cursor.getCount() == 0)
        {
            dataTxt.setText("No data found");
        }
        else
        {
            String data = "";

            while(cursor.moveToNext())
            {
                data += "Name: " + cursor.getString(1) + "\n";
                data += "Phone: " + cursor.getString(2) + "\n";
                data += "Address: " + cursor.getString(3) + "\n";
                data += "Service: " + cursor.getString(4) + "\n\n";
            }

            dataTxt.setText(data);
        }

        // 🔙 Back Button
        backBtn.setOnClickListener(v -> {
            finish(); // closes this screen
        });
    }
}