package com.example.bluehand;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button startBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        startBtn=findViewById(R.id.startBtn);

        startBtn.setOnClickListener(v -> {

            Intent intent =
                    new Intent(MainActivity.this,
                            com.example.bluehand.RequestServiceActivity.class);

            startActivity(intent);

        });

    }
}